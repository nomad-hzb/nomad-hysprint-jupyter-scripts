# Wetting Envelope Interactive Applet  
    This project provides an interactive applet for plotting wetting envelopes for materials and solvents based on their surface energy components.  
    
    ## Requirements  
    Install the required packages:  
    pip install -r requirements.txt  
    